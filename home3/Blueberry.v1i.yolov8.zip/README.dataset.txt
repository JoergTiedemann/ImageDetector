# Blueberry > 2025-12-23 12:07pm
https://universe.roboflow.com/blaubeeren/blueberry-1pg1g-h6vgf

Provided by a Roboflow user
License: CC BY 4.0

