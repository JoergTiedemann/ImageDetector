# blueberry > 2025-12-23 5:10pm
https://universe.roboflow.com/blaubeeren/blueberry-2wgpq-e1f5t

Provided by a Roboflow user
License: undefined

