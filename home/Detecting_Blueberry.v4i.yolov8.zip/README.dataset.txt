# Detecting_Blueberry > 2025-12-23 12:28am
https://universe.roboflow.com/blaubeeren/detecting_blueberry-phmc2

Provided by a Roboflow user
License: CC BY 4.0

